//"BISMILLAHIR   RAHMANIR   RAHIM"
//BUBBLE & SELECTION & QUICK - SORT ANIMATION HOTCHPOTCH
#define _CRT_SECURE_NO_WARNINGS//yo ho ..ALL HANDS ...HOIST THE COLOURS HIGH....
#include<windows.h>
#include"mmsystem.h"
# include "IGRAPHICS.h"//heave..ho..theaves & begger never shall we die,,filthy pirates..
//bool all=true;


int BRA=0,BDA=0,BAD=0,SRA=0,SDA=0,SAD=0,QRA=0,QDA=0,QAD=0;
int BRA1=0,BDA1=0,BAD1=0,SRA1=0,SDA1=0,SAD1=0,QRA1=0,QDA1=0,QAD1=0;
int MENUBOX=1,pic_x=0,pic_y=0,counter=0,m=1;
double xa[]={0,325,650};
double ya[]={813,0,813};
double xb[]={650,975,1300};
double yb[]={813,0,813};
double backx[]={17,37,37};
double backy[]={790,780,800};
/**now guest variables*/
bool b=0,c=0,x=0,y=0,z=0,QQ=0,SS=0,BB=0,replay1=1,replay2=0,instruction=0,MUSICON=true,play=false;int bmpb=0,bmps=0,bmpq=0;
int BADlimitx=800,BDAlimitx=800,Bmsec=3600,Ssec=40,localblinkcounter=1,globalblinkcounter=1;
int blinkposx=400,blinkposy=550;
int BADx_1=340,BADy_1=540,BADx_2=440,BADy_2=540,BADx_3=540,BADy_3=540,BADx_4=640,BADy_4=540,BADx_5=740,BADy_5=540;
int BDAoneposx=740,BDAoneposy=540,BDAtwoposx=640,BDAtwoposy=540,BDAthreeposx=540,BDAthreeposy=540;
int BDAfourposx=440,BDAfourposy=540,BDAfiveposx=340,BDAfiveposy=540,BRAlimitx=800;
int BRAoneposx=440,BRAoneposy=540,BRAtwoposx=740,BRAtwoposy=540,BRAthreeposx=340,BRAthreeposy=540;
int BRAfourposx=640,BRAfourposy=540,BRAfiveposx=540,BRAfiveposy=540;
int Qmsec=12000,lx=345,rx=745,pvx=345;
int QADx_1=340,QADy_1=540,QADx_2=440,QADy_2=540,QADx_3=540,QADy_3=540,QADx_4=640,QADy_4=540,QADx_5=740,QADy_5=540;
int QDAx_1=740,QDAy_1=540,QDAx_2=640,QDAy_2=540,QDAx_3=540,QDAy_3=540,QDAx_4=440,QDAy_4=540,QDAx_5=340,QDAy_5=540;
int QRAx_1=440,QRAy_1=540,QRAx_2=540,QRAy_2=540,QRAx_3=340,QRAy_3=540,QRAx_4=740,QRAy_4=540,QRAx_5=640,QRAy_5=540;
int SADlimitx=800,SADlimity=700,SADlimarrow=298,SADminposx=345;
int SADx_1=340,SADy_1=540,SADx_2=440,SADy_2=540,SADx_3=540,SADy_3=540,SADx_4=640,SADy_4=540,SADx_5=740,SADy_5=540;
int limitx=300,limity=700,lim=795,minposx=345;
int SDAx_1=740,SDAy_1=540,SDAx_2=640,SDAy_2=540,SDAx_3=540,SDAy_3=540,SDAx_4=440,SDAy_4=540,SDAx_5=340,SDAy_5=540;
int SRAlimitx=300,SRAlimity=700,SRAlim=795;
int SRAx_1=740,SRAy_1=540,SRAx_2=640,SRAy_2=540,SRAx_3=540,SRAy_3=540,SRAx_4=340,SRAy_4=540,SRAx_5=440,SRAy_5=540;
void openIt(){counter+=1;return;}
void rectangle()
{
    int i;
    int linex1=400,liney1=500,liney2=600;
       iSetColor(250,150,150);iFilledRectangle(285,485,530,130);///added
        iSetColor(115,64,132);iFilledRectangle(290,490,520,120);///added
        iSetColor(200,252,198);
        iFilledRectangle(300,500,500,100);
        for(i=1;i<=4;i++){
            iSetColor(030,050,030);
            iLine(linex1,liney1,linex1,liney2);
            linex1+=100;
        }
}
void changeblinkposBAD(){
        if(globalblinkcounter<=4){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=400;BADlimitx-=100;}
        }
        else if(globalblinkcounter<=7){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=400;BADlimitx-=100;}
        }
         else if(globalblinkcounter<=9){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==3){localblinkcounter=1;blinkposx=400;BADlimitx-=100;}
        }
        else if(globalblinkcounter==10){
            globalblinkcounter=11;
            localblinkcounter=2;
            blinkposx=3100;
            BADlimitx+=3100;bmpb=1;
        }

}
void textmoveBAD(){
    switch(globalblinkcounter*localblinkcounter){
       case 1:
            if(BADx_1<=440){
                BADx_1+=2;BADx_2-=2;
                if(BADx_1<390){BADy_2++;BADy_1--;}
                else{BADy_2--;BADy_1++;}
            }
            break;
        case 4:
            if(BADx_1<440){BADx_1=440;BADy_1=540;BADx_2=340;BADy_2=540;}
            else if(BADx_1<=540){
                BADx_1+=2;BADx_3-=2;
                if(BADx_1<490){BADy_3++;BADy_1--;}
                else{BADy_3--;BADy_1++;}
            }
            break;
        case 9:
            if(BADx_1<540){BADx_3=440;BADy_3=540;BADx_1=540;BADy_1=540;}
            else if(BADx_1<=640){
                BADx_1+=2;BADx_4-=2;
                if(BADx_1<590){BADy_4++;BADy_1--;}
                else{BADy_4--;BADy_1++;}
            }break;
        case 16:
            if(BADx_1<640){BADx_1=640;BADx_4=540;BADy_4=540;BADy_1=540;}
            else if(BADx_1<=740){
                BADx_1+=2;BADx_5-=2;
                if(BADx_1<690){BADy_5++;BADy_1--;}
                else{BADy_5--;BADy_1++;}
            }break;
        case 5:
            if(BADx_1<740){BADx_1=740;BADy_1=540;BADx_5=640;BADy_5=540;}
            else if(BADx_2<=440){
                BADx_2+=2;BADx_3-=2;
                if(BADx_2<390){BADy_3++;BADy_2--;}
                else{BADy_3--;BADy_2++;}
            }break;
        case 12:
            BADy_1=540;
            if(BADx_2<440){BADx_2=440;BADx_3=340;BADy_2=540;BADy_3=540;}
            else if(BADx_2<=540){
                BADx_2+=2;BADx_4-=2;
                if(BADx_2<490){BADy_4++;BADy_2--;}
                    else{BADy_4--;BADy_2++;}
            }break;
        case 21:
            if(BADx_2<540){BADx_2=540;BADx_4=440;BADy_4=540;BADy_2=540;}
            else if(BADx_2<=640){
                BADx_2+=2;BADx_5-=2;
                if(BADx_2<590){BADy_5++;BADy_2--;}
                else{BADy_5--;BADy_2++;}
            }
            break;
        case 8:
             if(BADx_2<640){BADx_2=640;BADx_5=540;BADy_2=540;BADy_5=540;}
             else if(BADx_3<=440){
                BADx_3+=2;BADx_4-=2;
                if(BADx_3<390){BADy_4++;BADy_3--;}
                else{BADy_4--;BADy_3++;}
             }break;
        case 18:
            if(BADx_3<440){BADx_3=440;BADx_4=340;BADy_3=540;BADy_4=540;}
            else if(BADx_3<=540){
                BADx_3+=2;BADx_5-=2;
                if(BADx_3<490){BADy_5++;BADy_3--;}
                else{BADy_5--;BADy_3++;}
            }break;
        case 10:
            if(BADx_3<540){BADx_3=540;BADy_3=540;BADy_5=540;BADx_5=440;}
             else if(BADx_4<=440){
                BADx_4+=2;BADx_5-=2;
                if(BADx_4<390){BADy_5++;BADy_4--;}
                else{BADy_5--;BADy_4++;}
            }break;

        default:
        {
            BADx_1=740;BADx_2=640;BADy_2=540;BADy_1=540;BADx_3=540;BADy_3=540;BADx_4=440;BADy_4=540;BADx_5=340;BADy_5=540;
        }
    }
}
void changeblinkposBDA(){
        if(globalblinkcounter<=4){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=400;BDAlimitx-=100;}
        }
        else if(globalblinkcounter<=7){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=400;BDAlimitx-=100;}
        }
         else if(globalblinkcounter<=9){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==3){localblinkcounter=1;blinkposx=400;BDAlimitx-=100;}
        }
        else if(globalblinkcounter==10){
            globalblinkcounter=11;
            localblinkcounter=2;
            blinkposx=3100;
            BDAlimitx+=3100;bmpb=1;
        }

}
void textmoveBDA(){
    switch(globalblinkcounter*localblinkcounter){
        case 1:
            if(BDAfiveposx<=440){
                BDAfiveposx+=2;BDAfourposx-=2;
                if(BDAfiveposx<390){BDAfiveposy++;BDAfourposy--;}
                else{BDAfiveposy--;BDAfourposy++;}
            }
            break;
        case 4:
            if(BDAfiveposx<440){BDAfiveposx=440;BDAfiveposy=540;BDAfourposx=340;BDAfourposy=540;}
            else if(BDAfiveposx<=540){
                BDAfiveposx+=2;BDAthreeposx-=2;
                if(BDAfiveposx<490){BDAfiveposy++;BDAthreeposy--;}
                else{BDAfiveposy--;BDAthreeposy++;}
            }
            break;
        case 9:
            if(BDAfiveposx<540){BDAthreeposx=440;BDAthreeposy=540;BDAfiveposx=540;BDAfiveposy=540;}
            else if(BDAfiveposx<=640){
                BDAfiveposx+=2;BDAtwoposx-=2;
                if(BDAfiveposx<590){BDAfiveposy++;BDAtwoposy--;}
                else{BDAfiveposy--;BDAtwoposy++;}
            }break;
        case 16:
            if(BDAfiveposx<640){BDAfiveposx=640;BDAtwoposx=540;BDAfiveposy=540;BDAtwoposy=540;}
            else if(BDAfiveposx<=740){
                BDAfiveposx+=2;BDAoneposx-=2;
                if(BDAfiveposx<690){BDAfiveposy++;BDAoneposy--;}
                else{BDAfiveposy--;BDAoneposy++;}
            }break;
        case 5:
            if(BDAfiveposx<740){BDAfiveposx=740;BDAfiveposy=540;BDAoneposx=640;BDAoneposy=540;}
            else if(BDAfourposx<=440){
                BDAfourposx+=2;BDAthreeposx-=2;
                if(BDAfourposx<390){BDAfourposy++;BDAthreeposy--;}
                else{BDAfourposy--;BDAthreeposy++;}
            }break;
        case 12:
            BDAfiveposy=540;
            if(BDAfourposx<440){BDAfourposx=440;BDAthreeposx=340;BDAfourposy=540;BDAthreeposy=540;}
            else if(BDAfourposx<=540){
                BDAfourposx+=2;BDAtwoposx-=2;
                if(BDAfourposx<490){BDAfourposy++;BDAtwoposy--;}
                else{BDAfourposy--;BDAtwoposy++;}
            }break;
        case 21:
            if(BDAfourposx<540){BDAfourposx=540;BDAtwoposx=440;BDAfourposy=540;BDAtwoposy=540;}
            else if(BDAfourposx<=640){
                BDAfourposx+=2;BDAoneposx-=2;
                if(BDAfourposx<590){BDAfourposy++;BDAoneposy--;}
                else{BDAfourposy--;BDAoneposy++;}
            }
            break;
        case 8:
             if(BDAfourposx<640){BDAfourposx=640;BDAoneposx=540;BDAfourposy=540;BDAoneposy=540;}
             else if(BDAthreeposx<=440){
                BDAthreeposx+=2;BDAtwoposx-=2;
                if(BDAthreeposx<390){BDAthreeposy++;BDAtwoposy--;}
                else{BDAthreeposy--;BDAtwoposy++;}
             }break;
        case 18:
            if(BDAthreeposx<440){BDAthreeposx=440;BDAtwoposx=340;BDAthreeposy=540;BDAtwoposy=540;}
            else if(BDAthreeposx<=540){
                BDAthreeposx+=2;BDAoneposx-=2;
                if(BDAthreeposx<490){BDAthreeposy++;BDAoneposy--;}
                else{BDAthreeposy--;BDAoneposy++;}
            }break;
        case 10:
            if(BDAthreeposx<540){BDAthreeposx=540;BDAthreeposy=540;BDAoneposy=540;BDAoneposx=440;}
             else if(BDAtwoposx<=440){
                BDAtwoposx+=2;BDAoneposx-=2;
                if(BDAtwoposx<390){BDAtwoposy++;BDAoneposy--;}
                else{BDAtwoposy--;BDAoneposy++;}
            }break;

        default:{BDAoneposx=340;
        BDAtwoposx=440;BDAtwoposy=540; BDAoneposy=540;
        BDAthreeposx=540;BDAthreeposy=540;
        BDAfourposx=640;BDAfourposy=540;
        BDAfiveposx=740;BDAfiveposy=540;
        }
    }
}
void changeblinkposBRA(){
        if(globalblinkcounter<=4){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=400;BRAlimitx-=100;}
        }
        else if(globalblinkcounter<=7){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=400;BRAlimitx-=100;}
        }
         else if(globalblinkcounter<=9){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==3){localblinkcounter=1;blinkposx=400;BRAlimitx-=100;}
        }
        else if(globalblinkcounter==10){
            globalblinkcounter=11;
            localblinkcounter=2;
            blinkposx=3100;
            BRAlimitx+=3100;bmpb=1;
        }

}
void textmoveBRA(){
    switch(globalblinkcounter*localblinkcounter){
        case 1:
           if(BRAthreeposx<=440){BRAoneposx-=2;BRAthreeposx+=2;
            if(BRAthreeposx<390){BRAoneposy--;BRAthreeposy++;}
            else {BRAoneposy++;BRAthreeposy--;}}
            break;
        case 4:
            BRAthreeposx=440;BRAthreeposy=540;BRAoneposy=540;BRAoneposx=340;
            break;
        case 9:
            if(BRAfiveposx<=640){
                BRAfiveposx+=2;BRAfourposx-=2;
                if(BRAfiveposx<590){BRAfiveposy++;BRAfourposy--;}
                else{BRAfiveposy--;BRAfourposy++;}}
                else{BRAfiveposx=640;BRAfiveposy=540;BRAfourposx=540;BRAfourposy=540;}
                break;
        case 16:if(BRAfiveposx<640){BRAfiveposx=640;BRAfiveposy=540;BRAfourposx=540;BRAfourposy=540;}
                else if(BRAfiveposx<=740){
                    BRAfiveposx+=2;BRAtwoposx-=2;
                    if(BRAfiveposx<690){BRAfiveposy++;BRAtwoposy--;}
                    else{BRAtwoposy++;BRAfiveposy--;}
                }else{BRAfiveposx=740;BRAfiveposy=540;BRAtwoposx=640;BRAtwoposy=540;}
                break;
        case 21:if(BRAfiveposx<740){BRAfiveposx=740;BRAfiveposy=540;BRAtwoposy=540;}
                else if(BRAfourposx<=640){
                    BRAfourposx+=2;BRAtwoposx-=2;
                    if(BRAfourposx<590){BRAfourposy++;BRAtwoposy--;}
                    else{BRAfourposy--;BRAtwoposy++;}
                }else{BRAfourposx=640;BRAtwoposx=440;BRAfourposy=540;BRAtwoposy=540;}
                break;
        case 18:if(BRAfourposx<640){BRAfourposx=640;BRAtwoposx=440;BRAfourposy=540;BRAtwoposy=540;}
                else if(BRAthreeposx<=540){
                    BRAthreeposx+=2;BRAtwoposx-=2;
                    if(BRAthreeposx<490){BRAthreeposy++;BRAtwoposy--;}
                    else{BRAthreeposy--;BRAtwoposy++;}
                }else{BRAthreeposx=540;BRAthreeposy=540;BRAtwoposy=540;BRAtwoposx=440;}
                break;

        default:{BRAoneposx=340;
        BRAtwoposx=440;BRAtwoposy=540; BRAoneposy=540;
        BRAthreeposx=540;BRAthreeposy=540;
        BRAfourposx=640;BRAfourposy=540;
        BRAfiveposx=740;BRAfiveposy=540;}

    }
}
void backgroundBRA(){
    iSetColor(125,128,250);
    iFilledRectangle(0,0,1300,900);
    iSetColor(25,25,25);
    iFilledRectangle(925,750,350,50);
	iSetColor(128,255,255);
	iRectangle(925,750,350,50);
	iText(950, 764, "BUBBLE SORT ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(64,0,128);
	iLine(877,550,1093,550);
    iText(877,560,"RANDOM to ASCENDING",GLUT_BITMAP_HELVETICA_18);
    rectangle();//CALLED
    if(localblinkcounter==1&&globalblinkcounter==1){ blinkposx=400,blinkposy=550;}
    if(b==1){
        iSetColor(128,255,255);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,100,50);
    }
    else{
        iSetColor(128,200,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,100,50);
    }
    iSetColor(205,240,200);
    iFilledEllipse(BRAlimitx+33,667,90,30);
    iSetColor(0,150,0);
    iLine(BRAlimitx,450,BRAlimitx,650);
    iText(BRAlimitx-12,655,"MAX LIMIT",GLUT_BITMAP_HELVETICA_18);
    if(blinkposx==3100){
        iSetColor(25,25,0);
        iText(400,650,">>SORTED IN ASCENDING ORDER>>",GLUT_BITMAP_HELVETICA_18);
        iText(400,250,"THANK YOU FOR WATCHING THIS,,,!!!",GLUT_BITMAP_TIMES_ROMAN_24);
    }
}
void changeblinkposQAD(){
    switch(localblinkcounter){
    case 1:blinkposx=750,blinkposy=550;//,,,,,,
    lx=345,rx=745,pvx=345;localblinkcounter=2;y=1;break;
    case 2:QADx_1=740;QADx_5=340;y=0;localblinkcounter=3;break;
    case 3:pvx=745;localblinkcounter=4;x=1;break;
    case 4:localblinkcounter=5;lx=445;break;case 5:localblinkcounter=6;lx=545;break;
    case 6:localblinkcounter=7;lx=645;break;
    case 7:localblinkcounter=8;lx=745;blinkposx=750;x=0;z=1;break;
    case 8:localblinkcounter=9;lx=345;rx=645;pvx=lx;blinkposx=650;z=0;break;//whitecap bay
    case 9:localblinkcounter=10;z=0;x=1;break;case 10:localblinkcounter=11;rx=545;break;
    case 11:localblinkcounter=12;rx=445;break;
    case 12:localblinkcounter=13;x=0;rx=345;z=1;blinkposx=350;break;
    case 13:localblinkcounter=14;z=0;blinkposx=650;lx=445;rx=645;pvx=lx;y=1;break;
    case 14:localblinkcounter=15;y=0;QADx_2=640;QADx_4=440;break;
    case 15:pvx=645;localblinkcounter=16;x=1;break;case 16:localblinkcounter=17;lx=545;break;
    case 17:localblinkcounter=18;lx=645;x=0;z=1;blinkposx=650;break;
    case 18:localblinkcounter=19;z=0;lx=445;rx=545;pvx=445;x=1;break;
    case 19:localblinkcounter=20;rx=445;blinkposx=450;x=0;z=1;break;
    case 20:localblinkcounter=21;rx=lx=pvx=545;blinkposx=550;break;
    case 21:z=0;localblinkcounter=22;lx=3200;rx=3300;pvx=3400;blinkposx=3500;break;
    case 22:localblinkcounter=3100;bmpq=1;break;
    default:{///bmpq=3;
    }
    }
}
void changeblinkposQRA(){
    switch(localblinkcounter){
    case 1:x=1;pvx=lx;localblinkcounter=2;break;case 2:rx=645;localblinkcounter=3;x=1;break;
    case 3:x=0;rx=545;localblinkcounter=4;break;case 4:y=1;x=0;localblinkcounter=5;break;
    case 5:x=0;y=0;QRAx_2=340;QRAx_3=540;localblinkcounter=6;break;
    case 6:localblinkcounter=7;pvx=rx;x=1;break;case 7:lx=445;localblinkcounter=8;x=1;break;
    case 8:localblinkcounter=9;lx=545;rx=545;blinkposx=550;x=0;z=1;break;//whitecap bay
    case 9:rx=445;lx=345;pvx=lx;y=1;z=0;localblinkcounter=10;break;
    case 10:localblinkcounter=11;y=1;QRAx_2=440;QRAx_1=340;break;
    case 11:y=0;pvx=rx;localblinkcounter=12;break;case 12:x=1;localblinkcounter=13;break;
    case 13:pvx=445;blinkposx=450;localblinkcounter=14;lx=rx=445;z=1;x=0;break;
    case 14:localblinkcounter=15;pvx=lx=rx=345;z=0;blinkposx=350;break;
    case 15:z=1;localblinkcounter=16;break;
    case 16:z=0;lx=645;rx=745;pvx=lx;blinkposx=750;y=1;localblinkcounter=17;break;
    case 17:y=0;localblinkcounter=18;QRAx_5=740;QRAx_4=640;break;
    case 18:localblinkcounter=19;pvx=745;break;case 19:x=1;localblinkcounter=20;break;
    case 20:x=0;lx=745;blinkposx=750;z=1;localblinkcounter=21;break;
    case 21:pvx=lx=rx=645;blinkposx=650;localblinkcounter=22;z=1;break;
    case 22:pvx=3300;lx=3100;rx=3200;z=0;blinkposx=3400;localblinkcounter=23;bmpq=1;break;
    default:{///bmpq=3;
    }
    }
}
void changeblinkposSAD(){
        if(globalblinkcounter==1)blinkposx=350;
        if(globalblinkcounter<=5){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==6){localblinkcounter=1;blinkposx=350;SADlimitx-=100;}
        }
        else if(globalblinkcounter<=9){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=350;SADlimitx-=100;}
        }
         else if(globalblinkcounter<=12){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=350;SADlimitx-=100;}
        }
        else if(globalblinkcounter==13){
            globalblinkcounter++;
            localblinkcounter++;
            blinkposx+=100;
        }
        else if(globalblinkcounter==14){
            blinkposx=3100;
            SADlimitx+=3100,SADlimity+=3100;
            globalblinkcounter=15;localblinkcounter=3; bmps=1;
        }
}
void textmoveSAD(){
    switch(globalblinkcounter*localblinkcounter){
        case 1:SADminposx=345;break;
        case 25:
            if(SADx_1<=740){
                SADx_1+=7;SADx_5-=7;
                if(SADx_1<540){SADy_1+=2;SADy_5-=2;}
                else{SADy_1-=2;SADy_5+=2;}
            }
            break;
        case 6:SADx_1=740;SADx_5=340;SADy_1=540;SADy_5=540;SADminposx=345;break;
        case 14:SADminposx=445;break;
        case 36:
                if(SADx_2<640){SADx_2+=4;SADx_4-=4;
                if(SADx_2<540){SADy_2++;SADy_4--;}
                else{SADy_2--;SADy_4++;}}
                else{SADminposx=545;}
            break;
        case 10:SADx_2=640;SADx_4=440;SADy_2=540;SADy_4=540;SADminposx=345;
                break;
        case 22:
            SADminposx=445;break;
        case 13:SADminposx=345;break;
        case 28:SADminposx=445;break;
        case 45:
               SADx_1=740;SADx_2=640;SADx_3=540;SADx_4=440;SADx_5=340;
            SADy_1=SADy_2=SADy_3=SADy_4=SADy_5=540;SADminposx=3200;SADlimarrow=3100;//KEEP IN MIND,,,,,,
            break;
        default:{}
    }
}
void changeblinkposSDA(){
        if(globalblinkcounter==1)blinkposx=350;
        if(globalblinkcounter<=5){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==6){localblinkcounter=1;blinkposx=450;limitx+=100;}
        }
        else if(globalblinkcounter<=9){
            if(localblinkcounter==6){localblinkcounter=1;blinkposx=450;limitx+=100;}
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=550;limitx+=100;}
        }
         else if(globalblinkcounter<=12){
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=550;limitx+=100;}
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=650;limitx+=100;}
        }
        else if(globalblinkcounter==13){
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=650;limitx+=100;}
            globalblinkcounter=14;
            localblinkcounter=14;
            blinkposx=3100;
            limitx+=3100,limity+=3100,lim+=3100;bmps=1;
        }

}
void textmoveSDA(){
    switch(globalblinkcounter*localblinkcounter){
        case 1:minposx=345;break;case 4:minposx=445;break;case 9:minposx=545;break;case 16:minposx=645;break;
        case 25:
            if(SDAx_5<=740){
                SDAx_5+=7;SDAx_1-=7;
                if(SDAx_5<540){SDAy_5+=2;SDAy_1-=2;}
                else{SDAy_5-=2;SDAy_1+=2;}
            }
            minposx=745;
            break;
        case 6:SDAx_1=340;SDAx_5=740;SDAy_1=540;SDAy_5=540;minposx=445;break;
        case 14:minposx=545;break;case 24:minposx=645;break;
        case 36:
                if(SDAx_4<=640){SDAx_4+=4;SDAx_2-=4;
                if(SDAx_4<540){SDAy_4++;SDAy_2--;}
                else{SDAy_4--;SDAy_2++;}}
            break;
        case 10:SDAx_2=440;SDAx_4=640;SDAy_2=540;SDAy_4=540;minposx=545;
                break;
        case 13:minposx=645;break;
        case 196:
             SDAx_1=340;SDAx_2=440;SDAx_3=540;SDAx_4=640;SDAx_5=740;
            SDAy_1=SDAy_2=SDAy_3=SDAy_4=SDAy_5=540;minposx=3200;
            break;
        default:{}
        }
}
void changeblinkposQDA(){
    switch(localblinkcounter){
    case 1:y=1;localblinkcounter=2;break;
    case 2:QDAx_1=340;QDAx_5=740;localblinkcounter=3;y=0;break;
    case 3:localblinkcounter=4;pvx=rx;x=1;break;
    case 4:localblinkcounter=5;lx=445;break;case 5:localblinkcounter=6;lx=545;break;
    case 6:localblinkcounter=7;lx=645;break;case 7:localblinkcounter=8;lx=745;blinkposx=750;x=0;z=1;break;
    case 8:lx=345;rx=645;pvx=lx;localblinkcounter=9;blinkposx=650;z=0;x=1;break;//whitecap bay
    case 9:localblinkcounter=10;rx=545;blinkposx=550;break;case 10:localblinkcounter=11;rx=445;blinkposx=445;break;
    case 11:localblinkcounter=12;lx=rx=345;blinkposx=350;x=0;z=1;break;
    case 12:z=0;localblinkcounter=13;lx=445;rx=645;pvx=lx;QDAx_4=640;QDAx_2=440;y=1;break;
    case 13:y=0;localblinkcounter=14;pvx=rx;x=1;break;case 14:localblinkcounter=15;lx=545;break;
    case 15:localblinkcounter=16;lx=rx=645;x=0;z=1;blinkposx=650;break;
    case 16:z=0;localblinkcounter=17;lx=445;rx=545;pvx=lx;x=1;break;
    case 17:localblinkcounter=18;rx=445;lx=445;blinkposx=450;x=0;z=1;break;
    case 18:localblinkcounter=19;lx=rx=pvx=545;blinkposx=550;z=1;break;
    case 19:localblinkcounter=20;z=0;lx=3200;rx=3300;pvx=3400;blinkposx=3500;break;
    case 20:localblinkcounter=3100;bmpq=1;break;
    default:{///bmpq=3;
    }
    }
}
void changeblinkposSRA(){
        if(globalblinkcounter==1)blinkposx=350;
        if(globalblinkcounter<=5){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==6){localblinkcounter=1;blinkposx=450;SRAlimitx+=100;}
        }
        else if(globalblinkcounter<=9){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==5){localblinkcounter=1;blinkposx=550;SRAlimitx+=100;}
        }
         else if(globalblinkcounter<=12){
            globalblinkcounter++;
            blinkposx+=100;
            localblinkcounter++;
            if(localblinkcounter==4){localblinkcounter=1;blinkposx=650;SRAlimitx+=100;}
        }
        else if(globalblinkcounter==13){
            globalblinkcounter++;
            localblinkcounter++;
            blinkposx+=100;
        }
        else if(globalblinkcounter==14){
            blinkposx=3100;
            SRAlimitx+=3100,SRAlimity+=3100,SRAlim+=3100;
            globalblinkcounter=15;localblinkcounter=3;bmps=1;
        }

}
void textmoveSRA(){
    switch(globalblinkcounter*localblinkcounter){
        case 1:minposx=345;break;case 9:minposx=545;break;case 16:minposx=645;break;
        case 25:
            if(SRAx_4<=740){
                SRAx_4+=7;SRAx_1-=7;
                if(SRAx_4<540){SRAy_4+=2;SRAy_1-=2;}
                else{SRAy_4-=2;SRAy_1+=2;}
            }
            minposx=745;
            break;
        case 6:SRAx_1=340;SRAx_4=740;SRAy_1=540;SRAy_4=540;minposx=445;break;
        case 14:minposx=545;break;
        case 24:minposx=645;break;
        case 36:
                if(SRAx_5<=640){SRAx_5+=4;SRAx_2-=4;
                if(SRAx_5<540){SRAy_5++;SRAy_2--;}
                else{SRAy_5--;SRAy_2++;}}
            break;
        case 10:SRAx_2=440;SRAx_5=640;SRAy_2=540;SRAy_5=540;minposx=545;
                break;
        case 13:minposx=645;break;
        case 28:minposx=745;
                if(SRAx_5<=740){
                    SRAx_5+=2;SRAx_4-=2;
                    if(SRAx_4>690){SRAy_5++;SRAy_4--;}
                    else{SRAy_4++;SRAy_5--;}
                }break;
        case 45:
            SRAx_1=340;SRAx_2=440;SRAx_3=540;SRAx_4=640;SRAx_5=740;
            SRAy_1=SRAy_2=SRAy_3=SRAy_4=SRAy_5=540;minposx=3200;
            break;
        default:
        {}
    }
}

void changeblinkpos(){
    if(BAD)changeblinkposBAD();
    else if(BDA)changeblinkposBDA();
    else if(BRA)changeblinkposBRA();
    else if(QDA)changeblinkposQDA();
    else if(SDA)changeblinkposSDA();
    else if(SAD)changeblinkposSAD();
    else if(SRA)changeblinkposSRA();
    else if(QAD)changeblinkposQAD();
    else if(QRA)changeblinkposQRA();
    else {}
}
void textmove(){
    if(BAD)textmoveBAD();
    else if(BDA)textmoveBDA();
    else if(BRA)textmoveBRA();
    else if(SDA)textmoveSDA();
    else if(SAD)textmoveSAD();
    else if(SRA)textmoveSRA();
    else {}
}

void backgroundBAD(){
    iSetColor(99,200,182);
    iFilledRectangle(0,0,1300,813);iSetColor(90,195,200);iFilledPolygon(xa,ya,3);iSetColor(95,190,190);iFilledPolygon(xb,yb,3);
	iSetColor(28,04,168);
	iRectangle(925,750,350,50);
	iText(950, 764, "BUBBLE SORT ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(64,0,128);
	iLine(877,550,1200,550);
    iText(877,560,"> > ASCENDING TO DESCENDING > >",GLUT_BITMAP_HELVETICA_18);
    rectangle();//CALLED
    if(localblinkcounter==1){blinkposx=400,blinkposy=550;}
    if(b==1){
        iSetColor(255,128,255);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,100,50);
    }
    else{
        iSetColor(128,255,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,100,50);
    }
    iSetColor(255,0,0);
    iLine(BADlimitx,450,BADlimitx,650);
    iText(BADlimitx-12,655,"<- MIN LIMIT",GLUT_BITMAP_HELVETICA_18);
    iSetColor(0,0,0);
     if(blinkposx==3100){
        iSetColor(59,25,0);
        iText(400,650,">>SORTED IN DESCENDING ORDER>>",GLUT_BITMAP_HELVETICA_18);
        iText(400,250,"THANK YOU FOR WATCHING THIS,,,,!!!",GLUT_BITMAP_TIMES_ROMAN_24);
    }
}
void backgroundBDA(){
    iSetColor(180,255,240);
    iFilledRectangle(0,0,1300,813);iSetColor(185,240,255);iFilledPolygon(xa,ya,3);iSetColor(205,250,230);iFilledPolygon(xb,yb,3);
	iSetColor(128,20,25);
	iRectangle(925,750,350,50);
	iText(950, 764, "BUBBLE SORT ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(64,0,128);
	iLine(877,550,1140,550);
    iText(877,560,"DSESCENDING to ASCENDING",GLUT_BITMAP_HELVETICA_18);
    rectangle();
    if(localblinkcounter==1){blinkposx=400,blinkposy=550;}
    if(b==1){
        iSetColor(128,229,255);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,100,50);
    }
    else{
        iSetColor(168,200,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,100,50);
    }
    iSetColor(255,0,0);
    iLine(BDAlimitx,450,BDAlimitx,650);
    iText(BDAlimitx-12,655,"MAX LIMIT",GLUT_BITMAP_HELVETICA_18);
    if(blinkposx==3100){//KJGLKJJJJJJJJJJJJJJJJJJJ
        iSetColor(52,25,0);
        iText(400,650,">>SORTED IN ASCENDING ORDER>>",GLUT_BITMAP_HELVETICA_18);
        iText(400,250,"THANK YOU FOR WATCHING THIS,MATE!!!",GLUT_BITMAP_TIMES_ROMAN_24);
    }
}
void backgroundQAD(){
    iSetColor(255,190,149);
    iFilledRectangle(0,0,1300,813);iSetColor(250,180,140);iFilledPolygon(xa,ya,3);iSetColor(255,200,150);iFilledPolygon(xb,yb,3);
    iSetColor(25,20,100);
    iFilledRectangle(925,750,355,50);
	iSetColor(240,208,200);
	iRectangle(925,750,355,50);
	iText(935, 764, """QUICK""   SORT   ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(12,50,100);
	if(localblinkcounter==2||localblinkcounter==14){iLine(lx,500,(lx+rx)/2,440);iLine((rx+lx)/2,440,rx,500);
            iText((lx+rx)/2-85,416,"NEED..to..SWAP",GLUT_BITMAP_TIMES_ROMAN_24);}//
    if(localblinkcounter==3||localblinkcounter==15)
        {iText((lx+rx/2)-420,250,"SWAPED....so....MOVE ""PIVOT"" to RIGHT----->>>",GLUT_BITMAP_TIMES_ROMAN_24);}
	iSetColor(16,1,15);
	iLine(877,550,1215,550);
    iText(877,560,">>>ASCENDING TO DESCENDING>>>",GLUT_BITMAP_HELVETICA_18);
    rectangle();//called
    iSetColor(197,100,117);
    iFilledRectangle(pvx-45,500,100,100);
    iSetColor(22,107,109);
    iFilledEllipse(pvx+5,720,60,30);
    iFilledRectangle(lx-105,360,70,40);
    iFilledRectangle(rx+37,360,85,40);
    iSetColor(240,239,245.5);
    iText(pvx-30,710,"PIVOT",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(rx+40,370,"RIGHT",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(lx-100,370,"LEFT",GLUT_BITMAP_TIMES_ROMAN_24);
    iSetColor(18,22,90);
    iLine(pvx,600,pvx,690);
    if(lx==rx)iText(500,320,"ALL LEFT SIDE ELEMENTS  >  ""PIVOT""  >  ALL RIGHT SIDE ELEMENTS",GLUT_BITMAP_HELVETICA_18);
    else if(pvx==rx){iText(500,320,"is [ PIVOT  <  LEFT ] ? ? ?",GLUT_BITMAP_HELVETICA_18);blinkposx=lx+5;}//
    else if((pvx==lx)&&(localblinkcounter!=3)){iText(500,320,"is [ PIVOT  >  RIGHT ] ? ? ?",GLUT_BITMAP_TIMES_ROMAN_24);blinkposx=rx+5;}//
    if(x)iText(500,290,"#YES!..Check Next..",GLUT_BITMAP_TIMES_ROMAN_24);
    if(y)iText(500,290,"#NO!..SWAP with PIVOT....",GLUT_BITMAP_TIMES_ROMAN_24);
    if(z)iText(280,240,"(Left=Right=Pivot)..all element left this position > PIVOT...&...all right side elements < PIVOT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(z)iText(300,160,"......SO,,,,,,,, WE,LL ..FIRST...*QUICK SORT*... THE..LEFT SUB ARRAYS*..& THEN..THE..*RIGHT SUB ARRAYS*....  ",GLUT_BITMAP_HELVETICA_18);
    iSetColor(0,120,0);
    iLine(lx-70,400,lx,500);
    iLine(rx+70,400,rx,500);
    if(localblinkcounter==1){blinkposx=750,blinkposy=550;}
    if(b==1){//blinking
        iSetColor(255,150,228);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    else{
        iSetColor(150,255,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    if((localblinkcounter>=8)){iSetColor(150,200,250);iFilledRectangle(700,500,100,100);}
    if(localblinkcounter>=13)iFilledRectangle(300,500,100,100);
    if(localblinkcounter>=20)iFilledRectangle(400,500,100,100);
    if(localblinkcounter>=18)iFilledRectangle(600,500,100,100);
    if(localblinkcounter>=22){iFilledRectangle(300,500,500,100);
                            iSetColor(25,10,50);
                            iText(350,380,"SORTED IN DESCENDING ORDER....!!",GLUT_BITMAP_HELVETICA_18);
                            iText(555,300,"""THANK YOU"" for WATCHING THIS......",GLUT_BITMAP_TIMES_ROMAN_24);
                            }
}
void backgroundQDA(){
    iSetColor(200,168,249);
    iFilledRectangle(0,0,1300,813);iSetColor(190,180,230);iFilledPolygon(xa,ya,3);iSetColor(190,160,250);iFilledPolygon(xb,yb,3);
    iSetColor(253,170,153);
    iFilledRectangle(925,750,355,50);
	iSetColor(4,28,200);
	iRectangle(925,750,355,50);
	iText(935, 764, """QUICK""   SORT   ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	if(localblinkcounter==2||localblinkcounter==13){iLine(lx,500,(lx+rx)/2,440);iLine((rx+lx)/2,440,rx,500);
            iText((lx+rx)/2-85,416,"NEED..to..SWAP",GLUT_BITMAP_TIMES_ROMAN_24);}//
    if(localblinkcounter==3||localblinkcounter==14)
        {iText((lx+rx/2)-420,250,"SWAPED....so....MOVE ""PIVOT"" to RIGHT----->>>",GLUT_BITMAP_TIMES_ROMAN_24);}
	iSetColor(16,15,15);
	iLine(877,550,1215,550);
    iText(877,560,">>>DESCENDING TO ASCENNDING>>>",GLUT_BITMAP_HELVETICA_18);
    rectangle();//called
    iSetColor(198,123,17);
    iFilledRectangle(pvx-45,500,100,100);
    iSetColor(137,237,179);
    iFilledEllipse(pvx,720,60,30);
    iFilledRectangle(lx-105,360,77,40);
    iFilledRectangle(rx+40,360,80,40);
    iSetColor(120,0,0);
    iLine(pvx,600,pvx,690);
    iText(pvx-30,710,"PIVOT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(lx==rx)iText(500,320,"ALL LEFT SIDE ELEMENTS  <  ""PIVOT""  <  ALL RIGHT SIDE ELEMENTS",GLUT_BITMAP_HELVETICA_18);
    else if(pvx==rx){iText(500,320,"is PIVOT > LEFT ?",GLUT_BITMAP_HELVETICA_18);blinkposx=lx+5;}//
    else if((pvx==lx)&&(localblinkcounter!=18)){iText(500,320,"is PIVOT < RIGHT ?",GLUT_BITMAP_TIMES_ROMAN_24);blinkposx=rx+5;}//
    if(x)iText(500,290,"#YES!..Check Next..",GLUT_BITMAP_TIMES_ROMAN_24);
    if(y)iText(500,290,"#NO!..SWAP with PIVOT....",GLUT_BITMAP_TIMES_ROMAN_24);
    if(z)iText(280,240,"(Left=Right=Pivot)..all element left this position < PIVOT...&...all right side elements > PIVOT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(z)iText(300,160,"......SO,,,,,,,, WE,LL ..FIRST...*QUICK SORT*... THE..LEFT SUB ARRAYS*..& THEN..THE..*RIGHT SUB ARRAYS*....  ",GLUT_BITMAP_HELVETICA_18);
    iSetColor(0,120,0);
    iLine(lx-70,400,lx,500);
    iLine(rx+70,400,rx,500);
    iText(rx+40,370,"RIGHT",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(lx-100,370,"LEFT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(localblinkcounter==1){blinkposx=350;blinkposy=550;}
    if(b==1){//blinking
        iSetColor(255,150,228);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    else{
        iSetColor(150,255,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    if((localblinkcounter>=8)){iSetColor(255,255,200);iFilledRectangle(700,500,100,100);}
    if(localblinkcounter>=12)iFilledRectangle(300,500,100,100);
    if(localblinkcounter>=16)iFilledRectangle(600,500,100,100);
    if(localblinkcounter>=18)iFilledRectangle(400,500,100,100);
    if(localblinkcounter>=20){iFilledRectangle(300,500,500,100);
                            iSetColor(25,10,50);
                            iText(350,380,"SORTED IN ASCENDING ORDER....!!",GLUT_BITMAP_HELVETICA_18);
                            iText(555,300,"""THANK YOU"" for WATCHING THIS......",GLUT_BITMAP_TIMES_ROMAN_24);
                            }
}
void backgroundQRA(){
    iSetColor(232,213,147);
    iFilledRectangle(0,0,1300,813);iSetColor(230,200,150);iFilledPolygon(xa,ya,3);iSetColor(220,200,155);iFilledPolygon(xb,yb,3);
    iSetColor(252,185,233);
    iFilledRectangle(925,750,355,50);
	iSetColor(4,28,100);
	iRectangle(925,750,355,50);
	iText(935, 764, "QUICK   SORT   ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	if(localblinkcounter==5||localblinkcounter==10||localblinkcounter==17){iLine(lx,500,(lx+rx)/2,440);iLine((rx+lx)/2,440,rx,500);
            iText((lx+rx)/2-85,416,"NEED to ""SWAP""...",GLUT_BITMAP_TIMES_ROMAN_24);}//
    if(localblinkcounter==6||localblinkcounter==11||localblinkcounter==18)
        {iText((lx+rx/2)-420,250,"SWAPED....so....MOVE ""PIVOT"" to RIGHT----->>>",GLUT_BITMAP_TIMES_ROMAN_24);}
	iSetColor(16,15,15);
	iLine(877,550,1170,550);
    iText(877,560,">>>RANDOM TO ASCENNDING>>>",GLUT_BITMAP_HELVETICA_18);
    rectangle();
    iSetColor(198,123,17);
    iFilledRectangle(pvx-45,500,100,100);
    iSetColor(171,164,279);
    iFilledEllipse(pvx,720,60,30);
    iFilledRectangle(lx-105,360,77,40);
    iFilledRectangle(rx+40,360,80,40);
    iSetColor(120,0,0);
    iLine(pvx,600,pvx,690);
    iText(pvx-30,710,"PIVOT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(lx==rx)iText(500,320,"ALL LEFT SIDE ELEMENTS  <  ""PIVOT""  <  ALL RIGHT SIDE ELEMENTS",GLUT_BITMAP_HELVETICA_18);
    else if(pvx==rx){iText(500,320,"is PIVOT > LEFT ?",GLUT_BITMAP_HELVETICA_18);blinkposx=lx+5;}//
    else if((pvx==lx)&&(localblinkcounter!=18)){iText(500,320,"is PIVOT < RIGHT ?",GLUT_BITMAP_TIMES_ROMAN_24);blinkposx=rx+5;}//
    if(x)iText(500,290,"#YES!..Check Next..",GLUT_BITMAP_TIMES_ROMAN_24);
    if(y)iText(500,290,"#NO!..SWAP with PIVOT....",GLUT_BITMAP_TIMES_ROMAN_24);
    if(z)iText(280,240,"(Left=Right=Pivot)..all element left this position < PIVOT...&...all right side elements > PIVOT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(z)iText(300,160,"......SO,,,,,,,, WE,LL ..FIRST...*QUICK SORT*... THE..LEFT SUB ARRAYS*..& THEN..THE..*RIGHT SUB ARRAYS*....  ",GLUT_BITMAP_HELVETICA_18);
    iSetColor(0,120,0);
    iLine(lx-70,400,lx,500);
    iLine(rx+70,400,rx,500);
    iText(rx+40,370,"RIGHT",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(lx-100,370,"LEFT",GLUT_BITMAP_TIMES_ROMAN_24);
    if(localblinkcounter==1){blinkposx=750,blinkposy=550;}
    if(b==1){//blinking
        iSetColor(255,150,228);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    else{
        iSetColor(150,255,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    if((localblinkcounter>=9)&&localblinkcounter!=3100){iSetColor(255,255,200);iFilledRectangle(500,500,100,100);}
    if(localblinkcounter>13)iFilledRectangle(400,500,100,100);
    if(localblinkcounter>=15)iFilledRectangle(300,500,100,100);
    if(localblinkcounter>=21)iFilledRectangle(700,500,100,100);
    if(localblinkcounter==23){iFilledRectangle(300,500,500,100);
                            iSetColor(25,10,50);
                            iText(350,380,"SOOORTED IN ASCENDING ORDER....!!",GLUT_BITMAP_HELVETICA_18);
                            iText(555,300,"THANK YOU for WATCHING THIS....",GLUT_BITMAP_TIMES_ROMAN_24);
                            }
}
void backgroundSAD(){
    iSetColor(255,150,199);
    iFilledRectangle(0,0,1300,813);iSetColor(250,140,200);iFilledPolygon(xa,ya,3);iSetColor(250,145,190);iFilledPolygon(xb,yb,3);
    iSetColor(99,0,64);
    iFilledRectangle(925,750,365,50);
	iSetColor(12,255,255);
	iText(935, 764, "SELECTION SORT ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(64,0,128);
	iLine(877,550,1170,550);
    iText(877,560,">ASCENDING TO DESCENDING>",GLUT_BITMAP_HELVETICA_18);
    rectangle();//CALLED
    iLine(SADminposx,350,SADminposx,490);
    iText(SADminposx-50,320,"*THE SMALLEST*",GLUT_BITMAP_HELVETICA_18);
    if(localblinkcounter==1&&globalblinkcounter==1){blinkposx=350,blinkposy=550;}
    if(b==1){
        iSetColor(250,158,128);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    else{
        iSetColor(150,255,205);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    iSetColor(55,28,0);
    iLine(SADlimitx,450,SADlimitx,650);
    iLine(300,SADlimity,SADlimitx,SADlimity);
    iText(SADlimarrow,694,"<",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(SADlimitx-5,694,">",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(SADlimitx-12,655,"SEARCH LIMIT",GLUT_BITMAP_HELVETICA_18);
     if(blinkposx==3100){
        iSetColor(0,25,40);
        iText(400,650,">>SORTED IN DESCENDING ORDER>>",GLUT_BITMAP_HELVETICA_18);
        iText(400,250,"THANK YOU FOR WATCHING THIS,,,!!!",GLUT_BITMAP_TIMES_ROMAN_24);
    }
}
void backgroundSDA(){
    iSetColor(219,150,192);
    iFilledRectangle(0,0,1300,813);iSetColor(220,160,190);iFilledPolygon(xa,ya,3);iSetColor(225,150,180);iFilledPolygon(xb,yb,3);
	iSetColor(12,255,255);
	iFilledRectangle(925,750,365,50);iSetColor(20,50,0);
	iText(935, 764, "SELECTION SORT ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(64,0,128);
	iLine(877,550,1170,550);
    iText(877,560,">DESCENDING TO ASCENNDING>",GLUT_BITMAP_HELVETICA_18);
    rectangle();//CALLED
    iLine(minposx,350,minposx,490);
    iText(minposx-50,320,"*THE SMALLEST*",GLUT_BITMAP_HELVETICA_18);
    if(localblinkcounter==1&&globalblinkcounter==1){blinkposx=350;blinkposy=550;}
    if(b==1){
        iSetColor(255,128,128);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    else{
        iSetColor(150,255,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    iSetColor(55,28,0);
    iLine(limitx,450,limitx,650);
    iLine(limitx,limity,800,limity);
    iText(limitx-2,695,"<",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(lim,694,">",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(limitx-12,655,"SEARCH LIMIT",GLUT_BITMAP_HELVETICA_18);
    if(blinkposx==3100){
        iSetColor(0,25,60);
        iText(400,650,">>SORTED IN ASCENDING ORDER>>",GLUT_BITMAP_HELVETICA_18);
        iText(400,250,"THANK YOU FOR WATCHING THIS,MATE!!!",GLUT_BITMAP_TIMES_ROMAN_24);
    }
}
void backgroundSRA(){
    iSetColor(255,150,249);
    iFilledRectangle(0,0,1300,813);iSetColor(250,140,250);iFilledPolygon(xa,ya,3);iSetColor(250,150,245);iFilledPolygon(xb,yb,3);
	iSetColor(12,25,255);
	iRectangle(925,750,365,50);
	iText(935, 764, "SELECTION SORT ANIMATION",GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(64,0,128);
	iLine(877,550,1170,550);
    iText(877,560,">RANDOM TO ASCENNDING>",GLUT_BITMAP_HELVETICA_18);
    rectangle();//CALLED
    iLine(minposx,350,minposx,490);
    iText(minposx-50,320,"*THE SMALLEST*",GLUT_BITMAP_HELVETICA_18);
    if(localblinkcounter==1&&globalblinkcounter==1){ blinkposx=350,blinkposy=550;}
    if(b==1){
        iSetColor(255,128,128);
        b=0;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    else{
        iSetColor(150,255,255);
        b=1;
        iFilledEllipse(blinkposx,blinkposy,50,60);
    }
    iSetColor(55,28,0);
    iLine(SRAlimitx,450,SRAlimitx,650);
    iLine(SRAlimitx,SRAlimity,800,SRAlimity);
    iText(SRAlimitx-2,694,"<",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(SRAlim,694,">",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(SRAlimitx-12,655,"SEARCH LIMIT",GLUT_BITMAP_HELVETICA_18);
    if(blinkposx==3100){
        iSetColor(0,25,60);
        iText(400,650,">>SORTED IN ASCENDING ORDER>>",GLUT_BITMAP_HELVETICA_18);
        iText(400,250,"THANK YOU FOR WATCHING THIS,,,!!!",GLUT_BITMAP_TIMES_ROMAN_24);
    }///if(bs)iShowBMP(100,100,"");
}
void background(){
    if(BAD)backgroundBAD();
    else if(BDA)backgroundBDA();
    else if(SAD)backgroundSAD();
    else if(BRA)backgroundBRA();
    else if(QAD)backgroundQAD();
    else if(QDA)backgroundQDA();
    else if(QRA)backgroundQRA();
    else if(SDA)backgroundSDA();
    else if(SRA)backgroundSRA();
}
void puttext1(int x_1,int y_1,int x_2,int y_2,int x_3,int y_3,int x_4,int y_4,int x_5,int y_5){
    iSetColor(0,0,0);
    iText(x_1,y_1,"1",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_2,y_2,"2",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_3,y_3,"3",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_4,y_4,"4",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_5,y_5,"5",GLUT_BITMAP_TIMES_ROMAN_24);
}
void puttext2(int x_1,int y_1,int x_2,int y_2,int x_3,int y_3,int x_4,int y_4,int x_5,int y_5){
    iSetColor(0,0,0);
    iText(x_1,y_1,"12",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_2,y_2,"23",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_3,y_3,"34",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_4,y_4,"45",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(x_5,y_5,"56",GLUT_BITMAP_TIMES_ROMAN_24);
}

void text(){
    if(replay1){
    if(BAD)puttext1(BADx_1,BADy_1,BADx_2,BADy_2,BADx_3,BADy_3,BADx_4,BADy_4,BADx_5,BADy_5);
    else if(BDA)puttext1(BDAoneposx,BDAoneposy,BDAtwoposx,BDAtwoposy,BDAthreeposx,BDAthreeposy,BDAfourposx,BDAfourposy,BDAfiveposx,BDAfiveposy);
    else if(BRA)puttext1(BRAoneposx,BRAoneposy,BRAtwoposx,BRAtwoposy,BRAthreeposx,BRAthreeposy,BRAfourposx,BRAfourposy,BRAfiveposx,BRAfiveposy);
    else if(QAD)puttext1(QADx_1,QADy_1,QADx_2,QADy_2,QADx_3,QADy_3,QADx_4,QADy_4,QADx_5,QADy_5);
    else if(QDA)puttext1(QDAx_1,QDAy_1,QDAx_2,QDAy_2,QDAx_3,QDAy_3,QDAx_4,QDAy_4,QDAx_5,QDAy_5);
    else if(QRA)puttext1(QRAx_1,QRAy_1,QRAx_2,QRAy_2,QRAx_3,QRAy_3,QRAx_4,QRAy_4,QRAx_5,QRAy_5);
    else if(SAD) puttext1(SADx_1,SADy_1,SADx_2,SADy_2,SADx_3,SADy_3,SADx_4,SADy_4,SADx_5,SADy_5);
    else if(SDA)puttext1(SDAx_1,SDAy_1,SDAx_2,SDAy_2,SDAx_3,SDAy_3,SDAx_4,SDAy_4,SDAx_5,SDAy_5);
    else if(SRA)puttext1(SRAx_1,SRAy_1,SRAx_2,SRAy_2,SRAx_3,SRAy_3,SRAx_4,SRAy_4,SRAx_5,SRAy_5);}
    if(replay2){
    if(BAD)puttext2(BADx_1,BADy_1,BADx_2,BADy_2,BADx_3,BADy_3,BADx_4,BADy_4,BADx_5,BADy_5);
    else if(BDA)puttext2(BDAoneposx,BDAoneposy,BDAtwoposx,BDAtwoposy,BDAthreeposx,BDAthreeposy,BDAfourposx,BDAfourposy,BDAfiveposx,BDAfiveposy);
    else if(BRA)puttext2(BRAoneposx,BRAoneposy,BRAtwoposx,BRAtwoposy,BRAthreeposx,BRAthreeposy,BRAfourposx,BRAfourposy,BRAfiveposx,BRAfiveposy);
    else if(QAD)puttext2(QADx_1,QADy_1,QADx_2,QADy_2,QADx_3,QADy_3,QADx_4,QADy_4,QADx_5,QADy_5);
    else if(QDA)puttext2(QDAx_1,QDAy_1,QDAx_2,QDAy_2,QDAx_3,QDAy_3,QDAx_4,QDAy_4,QDAx_5,QDAy_5);
    else if(QRA)puttext2(QRAx_1,QRAy_1,QRAx_2,QRAy_2,QRAx_3,QRAy_3,QRAx_4,QRAy_4,QRAx_5,QRAy_5);
    else if(SAD) puttext2(SADx_1,SADy_1,SADx_2,SADy_2,SADx_3,SADy_3,SADx_4,SADy_4,SADx_5,SADy_5);
    else if(SDA)puttext2(SDAx_1,SDAy_1,SDAx_2,SDAy_2,SDAx_3,SDAy_3,SDAx_4,SDAy_4,SDAx_5,SDAy_5);
    else if(SRA)puttext2(SRAx_1,SRAy_1,SRAx_2,SRAy_2,SRAx_3,SRAy_3,SRAx_4,SRAy_4,SRAx_5,SRAy_5);}
}
void algo(){if(bmpb>=1)bmpb++;if(bmps>=1)bmps++;if(bmpq>=1)bmpq++;}
void mmm(){if(counter==0)counter=1;else if(counter==1)counter==2;}
void iDraw()
{
    iClear();
    if(MENUBOX==1){
            iShowBMP(0,0,"bmpimages\\Rays 3.bmp");iSetColor(255,0,0);iText(1200,780,"[EXIT]",GLUT_BITMAP_HELVETICA_18);
            if(!instruction){iSetColor(20,20,20);iFilledRectangle(135,322,210,25);iSetColor(80,80,80);iFilledRectangle(394,145,427,18);iSetColor(128,255,255);iText(400,150,"CLICK INSTRUCTION PANEL TO GET INSTRUCTIONS....",GLUT_BITMAP_9_BY_15);}
            iText(150,327,"INSTRUCTION PANEL",GLUT_BITMAP_HELVETICA_18);
            if(instruction){iSetColor(266,236,236);iFilledRectangle(420,190,600,137);iLine(342,326,429,326);
            iSetColor(245,0,0);iText(950,315,">>CLOSE>>",GLUT_BITMAP_TIMES_ROMAN_10);iSetColor(0,0,0);
            iText(450,300,"1.First choose any type of SORT, then choose any type of ORDER",GLUT_BITMAP_HELVETICA_12);
            iText(450,270,"2.During animation running you can press BACK to return to MENUBOX",GLUT_BITMAP_HELVETICA_12);
            iText(450,240,"3.By clicking on REPLAY you can change 2 types of RANDOM NUMBERS in each order",GLUT_BITMAP_HELVETICA_12);
            iText(450,210,"4.Press [ EXIT ] button or 'q' to exit.....FOLLOW INSTRUCTIONS....THANK YOU",GLUT_BITMAP_HELVETICA_12);}
            if(replay1)iSetColor(33,255,255);else if(replay2)iSetColor(63,255,105);iFilledCircle(37,773,10,100);iText(52,765,"^REPLAY^",GLUT_BITMAP_HELVETICA_18);
            iSetColor(250,200,225);iText(150,740,"CHOOSE OPTIONS..PLEASE...",GLUT_BITMAP_9_BY_15);iSetColor(25,155, 231);
            if(BB)iSetColor(64,79,155);iFilledCircle(150,400,10,100);iRectangle(130,385,255,30);iText(200,395,"BUBBLE SORT",GLUT_BITMAP_HELVETICA_18);iSetColor(25,155, 231);
            if(SS)iSetColor(64,79,155);iFilledCircle(150,550,10,100);iRectangle(130,535,255,30);iText(200,545,"SELECTION SORT",GLUT_BITMAP_HELVETICA_18);iSetColor(25,155, 231);
            if(QQ)iSetColor(64,79,155);iFilledCircle(150,700,10,100);iRectangle(130,685,255,30);iText(200,695,"QUICK SORT",GLUT_BITMAP_HELVETICA_18);
            iSetColor(40,245,55);iShowBMP(1200,620,"bmpimages\\sound.bmp");
            if(SRA1||BRA1||QRA1)iSetColor(140,45,55);iFilledCircle(750,400,10,100);iRectangle(730,385,340,30);iText(800,395,"RANDOM to ASCENDING",GLUT_BITMAP_HELVETICA_18);iSetColor(40,245,55);
           if(BDA1||QDA1||SDA1)iSetColor(140,45,55);iFilledCircle(750,550,10,100);iRectangle(730,535,340,33);iText(800,545,"DESCENDING to ASCENDING",GLUT_BITMAP_HELVETICA_18);iSetColor(40,245,55);
           if(BAD1||QAD1||SAD1)iSetColor(140,45,55);iFilledCircle(750,700,10,100);iRectangle(730,685,340,30);iText(800,695,"ASCENDING to DESCENDING",GLUT_BITMAP_HELVETICA_18);
    }
    if(!MENUBOX){background();text();}
    if(!MENUBOX){iSetColor(225,0,0);
     if(bmpb>2)iShowBMP(0,120,"bmpimages\\bubble.bmp");if(bmps>2)iShowBMP(0,110,"bmpimages\\selection.bmp");
     if(bmpq>2)iShowBMP(0,120,"bmpimages\\quick.bmp");
    iText(45,782,"<<BACK<<",GLUT_BITMAP_HELVETICA_18);iFilledPolygon(backx,backy,3);}/**KEEP IT LAST OR IT CANT APPEAR**/
    if((counter!=0)&&counter<=2){iShowBMP(pic_x,0,"bmpimages\\project.bmp");if(pic_x<25)pic_x++;else pic_x+=250;if(pic_x>1500)counter=5;}///added
    if(!counter){iShowBMP(0,67,"bmpimages\\welcome.bmp");}///added
    if(MUSICON&&pic_x>1300&&pic_x<1500)PlaySound(0,0,0);///added
    if(MUSICON&&m&&pic_x>=1500){PlaySound("music\\iSound.wav", NULL , SND_LOOP | SND_ASYNC);m=0;}
}
void iMouseMove(int mx, int my){}
void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
        {
	    if(pic_x<25)pic_x+=5;
        printf("x = %d, y= %d\n",mx,my);
		///place your codes here
		if(mx>=1123&&mx<=1273&&my>=190&&my<=320)play=true;
		if(mx>=1200&&mx<=1300&&my>=620&&my<=773&&MUSICON){MUSICON=false;PlaySound(0,0,0);}///sound on off
		else if(mx>=1200&&mx<=1300&&my>=620&&my<=773&&(!MUSICON)){MUSICON=true; PlaySound("music\\iSound.wav", NULL , SND_LOOP | SND_ASYNC);}///sound on off
		if(MENUBOX&&mx>=148&&mx<=340&&my>328&&my<=345)instruction=1;
		if(MENUBOX&&instruction&&mx>=950&&mx<=1000&&my>312&&my<=322)instruction=0;
		if(MENUBOX&&mx>=1193&&mx<=1245&&my>=780&&my<=800)exit(0);
		if(MENUBOX&&mx>=27&&mx<=47&&my<=783&&my>=763&&replay1){replay2=1;replay1=0;}
		else if(MENUBOX&&mx>=27&&mx<=47&&my<=783&&my>=763&&replay2){replay2=0;replay1=1;}
		if((MENUBOX==0&&mx>=17&&mx<=37&&my>=780&&my<=800))///back button
		    {
           /// all=true;
            MENUBOX=1;QQ=0;SS=0;BB=0;BRA=0;BDA=0;BAD=0;SRA=0;SDA=0;SAD=0;QRA=0;QDA=0;QAD=0;BRA1=0;BDA1=0;BAD1=0;SRA1=0;SDA1=0;SAD1=0;QRA1=0;QDA1=0;QAD1=0;
            b=0;c=0;x=0;y=0;z=0;replay1=1;replay2=0;instruction=0;
BADlimitx=800;BDAlimitx=800;Bmsec=3600;Ssec=40;localblinkcounter=1;globalblinkcounter=1;///FOR THE LONG RECTANGLES
blinkposx=400;blinkposy=550;bmpb=0;bmps=0;bmpq=0;play=false;
BADx_1=340,BADy_1=540,BADx_2=440,BADy_2=540,BADx_3=540,BADy_3=540,BADx_4=640,BADy_4=540;BADx_5=740;BADy_5=540;
BDAoneposx=740,BDAoneposy=540,BDAtwoposx=640,BDAtwoposy=540,BDAthreeposx=540,BDAthreeposy=540;
BDAfourposx=440;BDAfourposy=540;BDAfiveposx=340;BDAfiveposy=540;BRAlimitx=800;
BRAoneposx=440;BRAoneposy=540;BRAtwoposx=740;BRAtwoposy=540;BRAthreeposx=340;BRAthreeposy=540;
BRAfourposx=640;BRAfourposy=540;BRAfiveposx=540;BRAfiveposy=540;
Qmsec=12000;lx=345;rx=745;pvx=345;
QADx_1=340;QADy_1=540;QADx_2=440;QADy_2=540;QADx_3=540;QADy_3=540;QADx_4=640;QADy_4=540;QADx_5=740;QADy_5=540;
QDAx_1=740;QDAy_1=540;QDAx_2=640;QDAy_2=540;QDAx_3=540;QDAy_3=540;QDAx_4=440;QDAy_4=540;QDAx_5=340;QDAy_5=540;
QRAx_1=440;QRAy_1=540;QRAx_2=540;QRAy_2=540;QRAx_3=340;QRAy_3=540;QRAx_4=740;QRAy_4=540;QRAx_5=640;QRAy_5=540;
SADlimitx=800;SADlimity=700;SADlimarrow=298;SADminposx=345;
SADx_1=340;SADy_1=540;SADx_2=440;SADy_2=540;SADx_3=540;SADy_3=540;SADx_4=640;SADy_4=540;SADx_5=740;SADy_5=540;
limitx=300;limity=700;lim=795;minposx=345;
SDAx_1=740;SDAy_1=540;SDAx_2=640;SDAy_2=540;SDAx_3=540;SDAy_3=540;SDAx_4=440;SDAy_4=540;SDAx_5=340;SDAy_5=540;
SRAlimitx=300;SRAlimity=700;SRAlim=795;
SRAx_1=740;SRAy_1=540;SRAx_2=640;SRAy_2=540;SRAx_3=540;SRAy_3=540;SRAx_4=340;SRAy_4=540;SRAx_5=440;SRAy_5=540;
		}
		if(mx >= 140 && mx <= 160 && my >= 390 && my <= 410 && MENUBOX == 1){QQ=0;BB=1;SS=0;}
		else if(mx >= 140 && mx <= 160 && my >= 540 && my <= 560 && MENUBOX == 1){SS=1;BB=0;QQ=0;}
		else if(mx >= 140 && mx <= 160 && my >= 690 && my <= 710 && MENUBOX == 1){BB=0;SS=0;QQ=1;}
		if(BB==1&& mx >= 740 && mx <= 760 && my >= 390 && my <= 410){BRA1=1;}
			else if(BB==1&& mx >= 740 && mx <= 760 && my >= 540 && my <= 560){BDA1=1;}
			else if(BB==1&& mx >= 740 && mx <= 760 && my >= 690 && my <= 710){BAD1=1;}
        if(SS==1&& mx >= 740 && mx <= 760 && my >= 390 && my <= 410){SRA1=1;}
			else if(SS==1&& mx >= 740 && mx <= 760 && my >= 540 && my <= 560){SDA1=1;}
			else if(SS==1&& mx >= 740 && mx <= 760 && my >= 690 && my <= 710){SAD1=1;}
        if(QQ==1&& mx >= 740 && mx <= 760 && my >= 390 && my <= 410){QRA1=1;}
			else if(QQ==1&& mx >= 740 && mx <= 760 && my >= 540 && my <= 560){QDA1=1;}
			else if(QQ==1&& mx >= 740 && mx <= 760 && my >= 690 && my <= 710){QAD1=1;}
		if(BDA1&&play){BDA=1;MENUBOX=0;}
		if(BRA1&&play){BRA=1;MENUBOX=0;}
		if(BAD1&&play){BAD=1;MENUBOX=0;}
		if(SDA1&&play){SDA=1;MENUBOX=0;}
		if(QDA1&&play){QDA=1;MENUBOX=0;}
		if(SRA1&&play){SRA=1;MENUBOX=0;}
		if(SAD1&&play){SAD=1;MENUBOX=0;}
		if(QRA1&&play){QRA=1;MENUBOX=0;}
		if(QAD1&&play){QAD=1;MENUBOX=0;}
}

	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{MENUBOX=1;QQ=0;SS=0;BB=0;BRA=0;BDA=0;BAD=0;SRA=0;SDA=0;SAD=0;QRA=0;QDA=0;QAD=0;bmpb=0;bmps=0;bmpq=0;
	BRA1=0;BDA1=0;BAD1=0;SRA1=0;SDA1=0;SAD1=0;QRA1=0;QDA1=0;QAD1=0;
	}
}
void iKeyboard(unsigned char key) {if (key == 'q') {exit(0);}}
void iSpecialKeyboard(unsigned char key) {if (key == GLUT_KEY_END)exit(0);}
int main()
{
    iSetTimer(Ssec,textmove);
    iSetTimer(Bmsec,changeblinkpos);/**NO CONDITION OKAY!!!*/
    iSetTimer(Qmsec,changeblinkpos);
    iSetTimer(600,algo);
    iSetTimer(10000,mmm);
    if(MUSICON&&pic_x<1300)PlaySound("music\\openit.wav", NULL , SND_LOOP | SND_ASYNC);
    if(MUSICON&&pic_x>=1500) PlaySound("music\\iSound.wav", NULL , SND_LOOP | SND_ASYNC);
	iInitialize(1300,813,"SORTING ANIMATIONS MADE BY US( 47 & 60)");
	return 0;
}
